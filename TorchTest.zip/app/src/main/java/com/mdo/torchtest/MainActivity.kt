package com.mdo.torchtest

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Typeface
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var cm: CameraManager
    private var torchId: String? = null
    private var maxLevel = 1
    private var level = 1
    private var torchOn = false

    private lateinit var levelLabel: TextView
    private lateinit var errorLabel: TextView
    private lateinit var toggleBtn: Button

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        cm = getSystemService(Context.CAMERA_SERVICE) as CameraManager

        val report = buildReport()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(32), dp(20), dp(24))
            setBackgroundColor(0xFF000000.toInt())
        }

        root.addView(TextView(this).apply {
            text = "Test intensità torcia"
            textSize = 22f
            setTextColor(0xFFFFFFFF.toInt())
            setTypeface(typeface, Typeface.BOLD)
        })

        root.addView(TextView(this).apply {
            text = report
            textSize = 13f
            typeface = Typeface.MONOSPACE
            setTextColor(0xFFE0E0E0.toInt())
            setTextIsSelectable(true)
            setPadding(0, dp(16), 0, dp(16))
        })

        root.addView(Button(this).apply {
            text = "COPIA REPORT"
            setOnClickListener {
                val clip = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                clip.setPrimaryClip(ClipData.newPlainText("report", report))
                Toast.makeText(this@MainActivity, "Copiato", Toast.LENGTH_SHORT).show()
            }
        })

        levelLabel = TextView(this).apply {
            textSize = 16f
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(0, dp(24), 0, dp(8))
        }
        root.addView(levelLabel)

        val seek = SeekBar(this).apply {
            max = (maxLevel - 1).coerceAtLeast(0)
            progress = max
            isEnabled = maxLevel > 1
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    level = p + 1
                    updateLabel()
                    if (torchOn && fromUser) applyTorch()
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        level = maxLevel
        root.addView(seek)

        toggleBtn = Button(this).apply {
            text = "ACCENDI"
            isEnabled = torchId != null
            setOnClickListener {
                torchOn = !torchOn
                applyTorch()
            }
        }
        root.addView(toggleBtn)

        errorLabel = TextView(this).apply {
            textSize = 13f
            setTextColor(0xFFFF6B6B.toInt())
            setPadding(0, dp(8), 0, 0)
        }
        root.addView(errorLabel)

        updateLabel()
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun updateLabel() {
        levelLabel.text = if (maxLevel > 1) "Livello $level / $maxLevel"
        else "Solo acceso / spento (nessun livello)"
    }

    private fun buildReport(): String {
        val sb = StringBuilder()
        sb.appendLine("Dispositivo: ${Build.MANUFACTURER} ${Build.MODEL}")
        sb.appendLine("Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})")
        sb.appendLine()

        var bestFacingBack = false
        for (id in cm.cameraIdList) {
            val c = cm.getCameraCharacteristics(id)
            val facing = when (c.get(CameraCharacteristics.LENS_FACING)) {
                CameraCharacteristics.LENS_FACING_BACK -> "posteriore"
                CameraCharacteristics.LENS_FACING_FRONT -> "frontale"
                CameraCharacteristics.LENS_FACING_EXTERNAL -> "esterna"
                else -> "?"
            }
            val hasFlash = c.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            var max: Int? = null
            var def: Int? = null
            if (Build.VERSION.SDK_INT >= 33) {
                max = c.get(CameraCharacteristics.FLASH_INFO_STRENGTH_MAXIMUM_LEVEL)
                def = c.get(CameraCharacteristics.FLASH_INFO_STRENGTH_DEFAULT_LEVEL)
            }
            sb.appendLine("Camera $id ($facing)")
            sb.appendLine("  flash: ${if (hasFlash) "sì" else "no"}")
            if (hasFlash) {
                sb.appendLine("  livello max: ${max ?: "n/d"}")
                sb.appendLine("  livello default: ${def ?: "n/d"}")
                sb.appendLine("  livelli regolabili: ${if ((max ?: 1) > 1) "SÌ" else "NO"}")
                val isBack = facing == "posteriore"
                if (torchId == null || (isBack && !bestFacingBack)) {
                    torchId = id
                    maxLevel = (max ?: 1).coerceAtLeast(1)
                    bestFacingBack = isBack
                }
            }
            sb.appendLine()
        }
        if (torchId == null) sb.appendLine("Nessuna camera con flash trovata.")
        else sb.appendLine("Test sulla camera ${torchId}")
        return sb.toString()
    }

    private fun applyTorch() {
        val id = torchId ?: return
        try {
            if (!torchOn) {
                cm.setTorchMode(id, false)
            } else if (Build.VERSION.SDK_INT >= 33 && maxLevel > 1) {
                cm.turnOnTorchWithStrengthLevel(id, level)
            } else {
                cm.setTorchMode(id, true)
            }
            errorLabel.text = ""
        } catch (e: Exception) {
            torchOn = false
            errorLabel.text = "Errore: ${e.javaClass.simpleName}: ${e.message}"
        }
        toggleBtn.text = if (torchOn) "SPEGNI" else "ACCENDI"
    }

    override fun onStop() {
        super.onStop()
        if (torchOn) {
            torchOn = false
            applyTorch()
        }
    }
}
